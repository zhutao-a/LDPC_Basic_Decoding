function [ L ] = decompose( m1, m2, y, u )
%DECOMPOSE Summary of this function goes here
%   Detailed explanation goes here

N = m1/2;
if mod(m2,2)==0
    i = m2/2;
else
    i = (m2+1)/2;
end

if N>1
    L1 = decompose(N, i, y(1:N), xor(u(1:2:2*i-2), u(2:2:2*i-2)));
    L2 = decompose(N, i, y(N+1:2*N), u(2:2:2*i-2));
else
    L1 = y(1);
    L2 = y(2); 
end

if mod(m2,2)==0
    L = g_fun(L1, L2, u(2*i-1));
else
    L = f_fun(L1, L2);
end

end

