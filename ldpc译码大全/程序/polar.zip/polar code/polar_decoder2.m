function [decode_out] = polar_decoder2(z, N, info_bit_flag_1024, info_bit_index, L)
%POLAR_DECODER2 Summary of this function goes here
%   Detailed explanation goes here


% ��ʼ������
PM = 0;
start = find(info_bit_flag_1024, 1, 'first');
trace = zeros(start-1,1);

for n = start:N
    tmp_PM = [];
    new_trace = [];
    for m = 1:size(trace,2)
        tmp = decompose( N, n, z, trace(:,m) );
        if info_bit_flag_1024(n)==0
            new_trace = [new_trace [trace(:,m); 0]];
            if tmp>0
                tmp_PM = [tmp_PM PM(m)];
            else
                tmp_PM = [tmp_PM PM(m)-abs(tmp)];
            end
        elseif info_bit_flag_1024(n)==1
            if tmp>0
                tmp_PM = [tmp_PM PM(m)];
                new_trace = [new_trace [trace(:,m); 0]];
                tmp_PM = [tmp_PM PM(m)-abs(tmp)];
                new_trace = [new_trace [trace(:,m); 1]];
            else
                tmp_PM = [tmp_PM PM(m)-abs(tmp)];
                new_trace = [new_trace [trace(:,m); 0]];
                tmp_PM = [tmp_PM PM(m)];
                new_trace = [new_trace [trace(:,m); 1]];
            end
        end
    end
    
    now_path_num = numel(tmp_PM);
    if now_path_num<L
        trace = new_trace;
        PM = tmp_PM;
    else
        [~,index] = sort(tmp_PM, 'descend');
        trace = new_trace(:,index(1:L));
        PM = tmp_PM(index(1:L));
    end
end

decode_out = trace(info_bit_index, :);

end

