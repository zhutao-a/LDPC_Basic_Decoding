
#include "mex.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

#define SIZE_DOUBLE sizeof(double)
#define SIZE_INT sizeof(int)

/*-----------------------------------------------------------------------*/
double f_fun(
        double      L1,
        double      L2)
{
    double a;
    double b;
    
    a = L1*L2;
    if(a>0)
        a = 1;
    else if(a<0)
        a = -1;
    else
        a = 0;
    
    if(fabs(L1)<fabs(L2))
        b = fabs(L1);
    else
        b = fabs(L2);
    
    return a*b;
}

/*-----------------------------------------------------------------------*/
double g_fun(
        double      L1,
        double      L2,
        int         u)
{
    double a;
    
    a = L1*L2;
    if(u%2==0)
        a = L1;
    else
        a = -L1;
    
    return a+L2;
}


/*-----------------------------------------------------------------------*/
double decompose(
        int         m1,
        int         m2,
        double      *y,
        int         *u)
{
    int             N;
    double          L;
    double          L1;
    double          L2;
    int             i;
    
    /*-------------------------------------------------------------------*/
    N = m1/2;
    if(m2%2==0)
        i = m2/2;
    else
        i = (m2+1)/2;
    
    /*-------------------------------------------------------------------*/
    if(N>1)
    {
        int *tmp_u1;
        int *tmp_u2;
        int j;
        tmp_u1 = (int *)malloc((i-1)*SIZE_INT);
        tmp_u2 = (int *)malloc((i-1)*SIZE_INT);
        for(j=1; j<=i-1; j++)
        {
            tmp_u1[j-1] = u[2*j-2]^u[2*j-1];
            tmp_u2[j-1] = u[2*j-1];
        }
        L1 = decompose(N, i, &y[0], tmp_u1);
        L2 = decompose(N, i, &y[N], tmp_u2);
        free(tmp_u1);
        free(tmp_u2);
    }
    else
    {
        L1 = y[0];
        L2 = y[1];
    }
    
    /*-------------------------------------------------------------------*/
    if(m2%2==0)
        L = g_fun(L1, L2, u[2*i-2]);
    else
        L = f_fun(L1, L2);
    
    return L;
            
}


/*-----------------------------------------------------------------------*/
void mexFunction(int nlhs, mxArray*plhs[],
        int nrhs, const mxArray *prhs[])
{
    int     m1;
    int     m2;
    double  *y;
    double  *u;
    int     *tmp_u;
    double  output;
    int     i;
    
    /*-------------------------------------------------------------------*/
    m1  = (int )mxGetScalar(prhs[0]);
    m2  = (int )mxGetScalar(prhs[1]);
    y   = (double *)mxGetPr(prhs[2]);
    u   = (double *)mxGetPr(prhs[3]);
    
    /*-------------------------------------------------------------------*/
    tmp_u = (int *)malloc(m1*SIZE_INT);
    for(i=0; i<m1; i++)
    {
        tmp_u[i] = (int)u[i];
    }
    output = decompose(m1, m2, y, tmp_u);
    free(tmp_u);
            
     /*-------------------------------------------------------------------*/
    plhs[0] = mxCreateDoubleScalar(output);
    return;
}










