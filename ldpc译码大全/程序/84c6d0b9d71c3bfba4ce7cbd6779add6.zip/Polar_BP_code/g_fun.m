function [ output ] = g_fun( L1, L2, u )
%G_FUN Summary of this function goes here
%   Detailed explanation goes here

output = (-1)^u*L1 + L2;

end

