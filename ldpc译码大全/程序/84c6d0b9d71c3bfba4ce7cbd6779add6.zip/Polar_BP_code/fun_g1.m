function L_R= fun_g1( x1,x2)




L_R=sign(x1)*sign(x2)*min(abs(x1),abs(x2));


end