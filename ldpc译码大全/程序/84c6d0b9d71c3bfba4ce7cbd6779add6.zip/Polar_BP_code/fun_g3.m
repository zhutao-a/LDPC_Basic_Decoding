function L_R= fun_g3( x1,x2)




L_R=0.9*sign(x1)*sign(x2)*min(abs(x1),abs(x2));


end