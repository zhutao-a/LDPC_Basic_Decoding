%%%% girth8-8,8

function [H,p,J,L]=girth8_8_8()

J=8;
L=8;
p=500;
shifter2=[0,1,2,3,4,5,6,7];
shifter3=[0,8,16,24,32,40,48,56];
shifter4=[0,0,0,0,0,0,0,0];
shifter5=[0,1,2,3,4,5,6,7];
shifter6=[0,8,16,24,32,40,48,56];
shifter7=[0,0,0,0,0,0,0,0];
shifter8=[0,1,2,3,4,5,6,7];

P=eye(p);
% i=length(shifter);

p21=circshift(P,shifter2(1));
p22=circshift(P,shifter2(2));
p23=circshift(P,shifter2(3));
p24=circshift(P,shifter2(4));
p25=circshift(P,shifter2(5));
p26=circshift(P,shifter2(6));
p27=circshift(P,shifter2(7));
p28=circshift(P,shifter2(8));

p31=circshift(P,shifter3(1));
p32=circshift(P,shifter3(2));
p33=circshift(P,shifter3(3));
p34=circshift(P,shifter3(4));
p35=circshift(P,shifter3(5));
p36=circshift(P,shifter3(6));
p37=circshift(P,shifter3(7));
p38=circshift(P,shifter3(8));

p41=circshift(P,shifter4(1));
p42=circshift(P,shifter4(2));
p43=circshift(P,shifter4(3));
p44=circshift(P,shifter4(4));
p45=circshift(P,shifter4(5));
p46=circshift(P,shifter4(6));
p47=circshift(P,shifter4(7));
p48=circshift(P,shifter4(8));

p51=circshift(P,shifter5(1));
p52=circshift(P,shifter5(2));
p53=circshift(P,shifter5(3));
p54=circshift(P,shifter5(4));
p55=circshift(P,shifter5(5));
p56=circshift(P,shifter5(6));
p57=circshift(P,shifter5(7));
p58=circshift(P,shifter5(8));

p61=circshift(P,shifter6(1));
p62=circshift(P,shifter6(2));
p63=circshift(P,shifter6(3));
p64=circshift(P,shifter6(4));
p65=circshift(P,shifter6(5));
p66=circshift(P,shifter6(6));
p67=circshift(P,shifter6(7));
p68=circshift(P,shifter6(8));

p71=circshift(P,shifter7(1));
p72=circshift(P,shifter7(2));
p73=circshift(P,shifter7(3));
p74=circshift(P,shifter7(4));
p75=circshift(P,shifter7(5));
p76=circshift(P,shifter7(6));
p77=circshift(P,shifter7(7));
p78=circshift(P,shifter7(8));

p81=circshift(P,shifter8(1));
p82=circshift(P,shifter8(2));
p83=circshift(P,shifter8(3));
p84=circshift(P,shifter8(4));
p85=circshift(P,shifter8(5));
p86=circshift(P,shifter8(6));
p87=circshift(P,shifter8(7));
p88=circshift(P,shifter8(8));
H=[P   P   P   P   P   P   P   P ;...
  p21 p22 p23 p24 p25 p26 p27 p28;...
  p31 p32 p33 p34 p35 p36 p37 p38;...
  p41 p42 p43 p44 p45 p46 p47 p48;...
  p51 p52 p53 p54 p55 p56 p57 p58;...
  p61 p62 p63 p64 p65 p66 p67 p68;...
  p71 p72 p73 p74 p75 p76 p77 p78;...
  p81 p82 p83 p84 p85 p86 p87 p88];
